#include<stdio.h>

void main(void){

	int x,y;

	printf("Enter x & y : ");
	scanf("%d %d",&x,&y);

	if (x = y)
		printf("in If\n");
	printf("out of If\n");
}
