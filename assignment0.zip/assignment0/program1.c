/*
 *Write a program that take two number (hardcoded) .Make the addition of that
 *variable and store it in ans variable and print
 */

#include<stdio.h>

void main(void){

	int x = 10;
	int y = 20;
	int ans;

	ans = x + y;
	printf("ans : %d\n",ans);		// + is a operator and x, y is operand
						// + is unary as well as binary operator

}
