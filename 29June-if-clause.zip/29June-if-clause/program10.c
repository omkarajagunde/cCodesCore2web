#include<stdio.h>

void main(void){
	
	int iDiedStatus = 1;

	if (!iDiedStatue == 1)
		printf("Im still alive ...");
}
