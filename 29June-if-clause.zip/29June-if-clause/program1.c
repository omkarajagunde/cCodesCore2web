#include<stdio.h>

void main(void){

	int age = 20;

	if (age > 18)
		printf("Adult\n");
}
