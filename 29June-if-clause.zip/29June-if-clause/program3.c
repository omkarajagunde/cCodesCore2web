#include <stdio.h>

void main(void){

	char toss = 'h';

	if (toss == 'h')
		printf("Heads ...");

	if (toss == 't')
		printf("Tails ...");

			
}
