#include<stdio.h>

void main(void){


	int iPuneCoronaCases = 12000;

	if (iPuneCoronaCases >= 8000 || iPuneCoronaCases > 10000){
		
		printf("Pune is in redZone ... ");
	}
}
