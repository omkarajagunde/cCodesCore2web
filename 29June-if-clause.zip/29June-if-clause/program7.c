#include<stdio.h>

void main(void){

	if (1 & 0)
		printf("bitwise and if is '1' then i will run ...");
}
