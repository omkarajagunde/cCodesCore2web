#include<stdio.h>

void main(void){

	int iMarks = 80;

	if (iMarks > 75 && iMarks < 100){
		printf("Gadi .... brumMmM brumMmM ....");
		printf("Mobile ....");
		printf("Wrist Watch .... Gussi ...");
	}
}
