#include<stdio.h>

void main(void){

	if (1 ^ 0)
		printf("bitwise XOR if is '1' then i will run ...");
}
