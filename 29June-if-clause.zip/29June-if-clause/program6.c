#include<stdio.h>

void main(void){
	
	int num = 5;

	if (num == 5)
		printf("I will run if num is 5 ...");
		printf("I will run even if num is or is not 5 ... bcoz im outside");
}
