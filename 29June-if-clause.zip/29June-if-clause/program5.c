#include<stdio.h>

void main(void){

	int num = 50;

	if (num == 50);{
		
		printf("Yedya if sampla ahe tu ';' dila tithech\n ata tu condition kahihihi dili tari mi run honar ahe ...");
	}
}
