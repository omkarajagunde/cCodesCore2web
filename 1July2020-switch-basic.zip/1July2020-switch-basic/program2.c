#include<stdio.h>

void main(void){
	
	int a = 65;
	
	// Here expression is valid and is terminated by semi colon
	// May give us Warning ... 
	switch(a);

}	
