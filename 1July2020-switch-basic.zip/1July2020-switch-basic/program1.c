#include<stdio.h>

void main(void){
	
	int a = 65;
	
	// Here there is error becuase Switch accpets exactly one
	// argument
	switch(){


	}

}	
