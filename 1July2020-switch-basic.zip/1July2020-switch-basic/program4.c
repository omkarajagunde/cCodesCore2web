#include<stdio.h>

void main(void){
	
	int a = 65;
	
	switch(a){

		case 65:printf("in case 65 of Switch ... \n");
	}

	printf("outside Switch ... \n");

}	
