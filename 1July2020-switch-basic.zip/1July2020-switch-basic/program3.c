#include<stdio.h>

void main(void){
	
	int a = 65;
	
	// below Switch will get printed as
	// printf("in Switch"); is not in case
	switch(a){

		printf("in Switch");
	}

	printf("below Switch");

}	
