#include<stdio.h>


void main(void){
	
	int a = 1;
	switch(a)
	case 1: printf("One\n");
	
	int b = 2;
	switch(b)
	case 2: printf("Two\n");
	
	int c = 3;
	switch(c)
	case 3: printf("Three\n");
	
	int d = 4;
	switch(d)
	case 4: printf("Four\n");
	
	int e = 5;
	switch(e)
	case 5: printf("Five\n");
}

