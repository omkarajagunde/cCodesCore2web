#include<stdio.h>

void main(void){

	float val;

	printf("Enter a float value : ");
	// Format to store int and float is different hence value printed 
	// is Zero ...
	scanf("%d", &val);

	printf("value : %f\n", val);
}
