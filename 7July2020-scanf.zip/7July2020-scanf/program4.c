#include<stdio.h>

void main(void){

	char ch;

	printf("Enter a character value : ");
	scanf("%c", &ch);

	printf("value : %c\n", ch);
	printf("ASCII value : %d\n", ch);
}
