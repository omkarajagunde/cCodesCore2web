#include<stdio.h>

void main(void){

	float val;

	printf("Enter a float value : ");
	scanf("%f", &val);

	printf("value : %f\n", val);
}
