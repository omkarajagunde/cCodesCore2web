#include<stdio.h>

void main(void){

	char ch1, ch2;

	printf("Enter 2 characters : ");
	scanf("%c %c", &ch1, &ch2);

	printf("value ch1 : %c\n", ch1);
	printf("value ch2 : %c\n", ch2);
}
