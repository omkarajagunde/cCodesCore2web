#include<stdio.h>

void main(void){

	float val, valOne;

	printf("Enter a float value : ");
	scanf("%f%f", &val, &valOne);

	printf("value val: %f\n", val);
	printf("value valOne: %f\n", valOne);
}
