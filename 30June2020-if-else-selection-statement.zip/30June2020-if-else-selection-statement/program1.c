#include<stdio.h>

void main(void){

	int age = 21;

	if (age >= 21)
		printf("Adult");
	else
		printf("Teenager");
}
