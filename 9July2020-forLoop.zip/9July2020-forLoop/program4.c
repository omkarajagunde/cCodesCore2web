#include<stdio.h>

void main(void){

	for (int i = 1; i<=10; i++){

		if (i % 2 != 0)
			printf("Odd : %d\n", i);
		else
			printf("Even : %d\n", i);
	}
}
