#include<stdio.h>

void main(void){

	for (int i = 10; i>=1; --i)
		printf("%d\n", i);
}
