#include<stdio.h>

void main(void){
	
	for (int i = 1; i<=50; i++){
		
		if (i % 5 == 0)
			printf("%d\n", i);
	}
}
