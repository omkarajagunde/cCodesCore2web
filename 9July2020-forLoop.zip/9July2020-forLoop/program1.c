#include<stdio.h>

void main(){

	for (int num = 0; num <= 9; ++num){

		printf("Core2Web ...\n");
	}
}
