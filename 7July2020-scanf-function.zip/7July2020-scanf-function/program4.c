#include<stdio.h>

void main(void){

	int a,b;
	printf("Enter a and b number :");
	scanf("%d%d",&a,&b);

	//scanf("%d\n"); dont write like this ...
	printf("%d + %d = %d\n",a,b,a+b);
	
}
