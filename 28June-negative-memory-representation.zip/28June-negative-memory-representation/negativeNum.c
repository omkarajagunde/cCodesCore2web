#include<stdio.h>

void main(void){

	int a = -35;
	printf("%d\n", a);
}
