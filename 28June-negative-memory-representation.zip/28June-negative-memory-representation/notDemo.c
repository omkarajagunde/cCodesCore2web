#include<stdio.h>

void main(void){

	int a = 35;
	int b = -35;
	int c = 20;
	int d = -20;

	printf("%d\n", ~(a));
	printf("%d\n", ~(b));
	printf("%d\n", ~(c));
	printf("%d\n", ~(d));

}
