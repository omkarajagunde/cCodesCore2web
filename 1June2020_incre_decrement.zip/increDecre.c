# include<stdio.h>

void main(void){

	int b = 20;
	int a = 10;

	// pre increment
	printf("%d\n",++a);	//11
	// post increment
	printf("%d\n",a++);	//11

	// pre decrement
	printf("%d\n",--b);	//19
	// post decrement
	printf("%d\n",b--);	//19
}
